import java.util.Scanner;
public class matrixsum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter no. of rows : ");
		int r = sc.nextInt();
		System.out.println("enter no. of columns : ");
		int c= sc.nextInt();
		int[][] mat = new int[r][c];
		int[][] mat2 = new int[r][c];
		int[][] mat3 = new int[r][c];
		for (int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				System.out.println("enter the value for x["+ i+"]["+j+"]");
				mat[i][j]= sc.nextInt();
			}
		}
		for (int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				//System.out.println("enter the value for x["+ i+"]["+j+"]");
				System.out.print(mat[i][j]+" ");
			}
			System.out.println();
		}
		
		for (int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				//System.out.println("enter the value for x["+ i+"]["+j+"]");
				//System.out.print(mat[i][j]+" ");
				mat2[j][i]= mat[i][j];
				//System.out.print(mat2[i][j]+" ");
			}
			
		}
		System.out.println("the transpose is : ");
		for (int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				//System.out.println("enter the value for x["+ i+"]["+j+"]");
				//System.out.print(mat[i][j]+" ");
				System.out.print(mat2[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println("the addition is : ");
		
		for (int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				//System.out.println("enter the value for x["+ i+"]["+j+"]");
				mat3[i][j]=mat[i][j]+mat2[i][j];
			}
			//System.out.println();
		}
		for (int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				//System.out.println("enter the value for x["+ i+"]["+j+"]");
				//System.out.print(mat[i][j]+" ");
				System.out.print(mat3[i][j]+" ");
			}
			System.out.println();
		}
	}

}
