package strings;

import java.util.Scanner;

//WAP to calculate 2 strings length without using string function 
public class strings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc= new Scanner(System.in);
System.out.println("enter 2 strings :");
String s1 = sc.nextLine();
int c1=0;

for(char x : s1.toCharArray())
{
	c1++;
	
}
String s2 = sc.nextLine();
int c2=0;
for(char x : s2.toCharArray())
{
	c2++;
	
}
//System.out.println(c1);
//System.out.println(c2);

int l=c1+c2+1;
char[] s3 = new char[l];
for (int i=0;i<c1;i++ )
{
	s3[i]= s1.charAt(i);
}
//System.out.println(s3);
s3[c1]= ' ';
//System.out.println(s3);
int j=0;
for (int i=c1+1;i<l;i++ )
{
	s3[i]= s2.charAt(j);
	j++;
}
System.out.println(s3);


	}

}
