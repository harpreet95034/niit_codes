/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pattern4;

/**
 *
 * @author GKP_student
 */
public class Pattern4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
        for (int i = 0 ; i <4;i++) //no. of lines
        {
            for(int j = 0;j<3-i;j++)//no.of spaces
            {
                System.out.print(" ");
            }
            for (int j = 0 ; j <2*i+1;j++ )
            {
                System.out.print("*");
            }
            /*int j=0 ;
            do
            {
                System.out.print("*");
                j++;
            }while( j < i);
            for ( int k = 0 ;k<i+1;k++ )
            {
            if (i <1)
            {
                System.out.print(" ");
            }
            else
            {
                 System.out.print("*");
            }
            }*/
            
            System.out.println();
        }
        for (int i = 0 ; i<4;i++)
        {
            for (int j=4;j>4-i;j--)
            {
                System.out.print(" ");
            }
            for(int j=2*i;j<7;j++)
            {
                System.out.print("*");
            }
            System.out.println();
        }
    }
    
}
